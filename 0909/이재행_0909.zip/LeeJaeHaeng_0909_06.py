
a  = range(0,10)
b = range(0,10,2)
c = [0,2,4,6,8,10]

for i in a:
    print(i, end=" ")
print("\n")

for i in b:
    print(i,end="")
print("\n")

for i in c:
    print(i,end="")
print("\n")
 
for _ in range(10):
    print("선문대학교 사랑합니다")