# 과제1: 리스트, 튜플, 딕셔너리
# 이름: 컴퓨터공학부 이재행
# 날짜: 24.09.11
univ="선문대학교"
text="동해물과 백두산이 마르고 닳도록"
line=text.split(" ")

print(univ, "type: ",type(univ))
print(univ[0], "type: ",type(univ[0]))
print(univ[0:3], "type: ",type(univ[0:3]))
print(univ[-1], "type: ",type(univ[-1]))

print(line[0], "type: ", type(line[0]))

print(line, "type: ",type(line))