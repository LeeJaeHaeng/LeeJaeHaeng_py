# 과제1: 리스트, 튜플, 딕셔너리
# 이름: 컴퓨터공학부 이재행
# 날짜: 24.09.11
list_a = [273, "321", "선문대", True]

print(list_a[1], "type: ", type(list_a))
print(list_a[0], "type: ", type(list_a))  
print(list_a[3], "type: ", type(list_a))  
print(list_a[4], "type: ", type(list_a))  


print(list_a[1][1], "type: ", type(list_a)) 
print(list_a[1][1], "type: ", type(list_a)) 
print(list_a[0][1], "type: ", type(list_a)) 